module.exports = require('./lib/shipit');
