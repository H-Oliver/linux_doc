#!/bin/bash
datetime=` date -d "yesterday" +"%F"`
log_file=/var/log/supervisord.log.$datetime
log_path=/var/log/server-log
mail="oliver@shangtv.cn,will@shangtv.cn,cart@shangtv.cn,sky@shangtv.cn,beard@shangtv.cn"
mail1="oliver@shangtv.cn"

function attachment(){
    cd $log_path
    find . -type f -name "yshd-log-${datetime}-*" -exec zip -q -m -r yshd-log-${datetime}.zip {} \;
}

if [ ! -e $log_file ]
then
  echo "" | mail -s "Supervisord log日志文件不存在" $mail1
else
  erro_status=`less $log_file | egrep 'terminated by SIGABRT|exit status 2' | awk -F "[ ,]" '{print $1,$2,$6,$5}'`
  erro_num=`less $log_file | egrep 'terminated by SIGABRT|exit status 2' | wc -l`
   if [ $erro_num -gt 0 ]
   then
     text="$datetime 服务器总奔溃次数: $erro_num\n\n ---------服务器进程奔溃时间统计如下---------\n\n $erro_status\n\n 日志详情见附件"
     title="服务器奔溃昨日统计报表"
     attachment
     att=`find $log_path/yshd-log-${datetime}.zip`
     echo -e "$text" | mail -s "$title" -a $att $mail
   fi
fi
