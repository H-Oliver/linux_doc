#!/bin/bash
. /etc/init.d/functions

listen_script=/script/listen_server.sh
listen_proc=`ps aux |grep -w "$listen_script" |grep -v grep |awk '{print $2}'`
listen_num=`ps aux |grep -w "$listen_script" |grep -v grep |awk '{print $2}'|wc -l`
echo "$listen_num $listen_proc" 
[ $listen_proc ]&& $SETCOLOR_SUCCESS 
  echo -e "`basename $listen_script` Running \E[0m"
  reture $
