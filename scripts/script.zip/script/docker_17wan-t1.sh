#!/bin/bash
while :
do
  clear
  echo -e "\n                      本脚本用来创建后台服务器docker容器\n"
  read -p "        请输入要创建的17玩容器名（前缀需要17wan-）：" container
  read -p "        请输入容器映射到外部的端口号：" port
  names=`sudo docker ps -a | awk '{print $NF}'|grep $container 2>/dev/null`
  [[ -z $port ]] || [[ $port == ^[0-9]*$ ]] || [[ -z $container ]] || [[ ! "$container" =~ "17wan-" ]] || [[ "$container" == "$names" ]]||{
  echo "$container $port ok"
  sudo docker login -u admin -p shangtv2017 registry.shangtv.cn:5000
  sudo docker run -tid --restart=always --name $container --privileged=true --link mariadb-server:mariadb -p $port:3003 -v /opt/17wanserver:/go/src/17wan registry.shangtv.cn:5000/17wanserver:v2.0
  break
  }
done
