#!/bin/sh
proc=/data/niuniu/yshd_game
datetime=`date +%F-%T`
log_path=/var/log/server-log
mail="oliver@shangtv.cn,will@shangtv.cn,cart@shangtv.cn,sky@shangtv.cn,beard@shangtv.cn"
mail1="oliver@shangtv.cn"

while true
do
    procnum=`ps aux |grep $proc |grep -v grep |wc -l`
    if [ "$procnum" -eq "0" ];then
        text="--------`date +%F\ %T`---------\n 服务器奔溃，请排查故障\n 服务器奔溃，请排查故障\n 服务器奔溃，请排查故障\n \n重要的事说三遍"
        echo -e "$text" | mail -s "【重要】YSHD_GAME服务器奔溃，请排查故障!!!" $mail
        [ ! -d $log_path ]&& mkdir -m 775 $log_path
        zip -q -r $log_path/yshd-log-${datetime}.zip /var/log/yshd_game-server.*
    fi
    sleep 2
done
