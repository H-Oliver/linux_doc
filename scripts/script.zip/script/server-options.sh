#!/bin/bash
### BEGIN INFO
# Description:
#             This is a server upgrade script!
# Author: Oliver
### END INFO

if [ $UID -ne 0 ];then
  echo "Yore not supper user,please call root!"
  exit 1   
fi

[ -f /etc/init.d/functions ]&& . /etc/init.d/functions

time=_` date +%y%m%d%H%M%S `
proc=yshd_game
package_file=yshd_game.zip
config_file=$datadir/config.ini
datadir=/data/niuniu
backdir=/data/server-backup
packdir=/data/server-package
upgrade_log=/var/log/yshd-game-upgrade.log
restart_log=/var/log/yshd-game-restart.log
listen_script=/script/listen_server.sh

listen_PID=`sudo ps aux |grep -w "$listen_script" |grep -v grep |awk '{print $2}'`
listen_NUM=`sudo ps aux |grep -w "$listen_script" |grep -v grep |awk '{print $2}'|wc -l`
#process_PID=`sudo ps aux |grep -w "$proc" |grep -v grep | awk '{print $2}'`
process_PID=`sudo supervisorctl status |grep -w "$proc" |grep -v "grep" |awk -F"[ ,]+" '{print $4}'`
process_NUM=`sudo supervisorctl status |grep -w "$proc" |grep -v "grep" |awk -F"[ ,]+" '{print $4}'|wc -l`

#屏蔽菜单其它输入
function trapper(){
  trap ':' INT EXIT TSTP TERM HUP
}

#倒计时
function countdown(){
seconds_left=10
echo -e "${GREEN_COLOR}                操作持续${seconds_left}秒钟，请耐心等待…………$RES"
while [ $seconds_left -gt 0 ];do
  echo -n -e "${GREEN_COLOR}               正在倒计时,还剩:${seconds_left}秒"
  sleep 1
  seconds_left=$(($seconds_left - 1))
  echo -ne "\r     \r"
done
}

#暂停进程实时监控
function stop_listen(){
[ $listen_NUM -ne 0 ] && {
  sudo kill -19 $listen_PID
}
}

#继续实时监控脚本
function cont_listen(){
[ $listen_NUM -ne 0 ] && {
  sudo kill -18 $listen_PID
}
}

#升级服务器
function upgrade_srv(){
clear
echo -e "${YELLOW_COLOR}              登陆用户：$(logname)  操作时间：`date +%F\ %T`$RES" | tee -a $upgrade_log

#查询服务器重启之前的状态
echo -e "${YELLOW_COLOR}              升级前服务器进程PID：${process_PID}$RES"

if [ -e "$datadir/$proc" -a -e "$packdir/yshd_game.zip" ]; then
    #备份原程序
    sudo mv $datadir/yshd_game $backdir/yshd_game$time 2>&1 > /dev/null
    #解压新程序到工作目录
    sudo unzip $packdir/yshd_game.zip -d $datadir/ 2>&1 > /dev/null
    #备份新程序包
    sudo mv $packdir/yshd_game.zip $packdir/yshd_game.zip$time 2>&1 > /dev/null
    #给新程序增加可执行权限
    sudo chmod a+x $datadir/yshd_game
    #给进程发送重启信号
    sudo kill -2 $process_PID
    countdown
    [ $process_NUM -ne 0 ] && {
      echo -e "${GREEN_COLOR}                服务器(`date +%F\ %T`)升级完成$RES" | tee -a $upgrade_log
    }

else
    if [ ! -e "$datadir/$proc" -a -e "$packdir/$package_file" ]; then
        echo -e "${RED_COLOR}          注意:服务器进程文件\"$proc\"不存在，可能已移除或删除了哦$RES"

    elif [ -e "$datadir/$proc" -a ! -e "$packdir/$package_file" ]; then
        echo -e "${RED_COLOR}          注意:更新包\"$package_file\"未上传到服务器,请上传程序包哦$RES"

    elif [ ! -e "$datadir/$proc" -a ! -e "$packdir/$package_file" ]; then
        echo -e "${RED_COLOR}          注意:更新包\"$package_file\"未上传到服务器,请上传程序包哦$RES"
        echo -e "${RED_COLOR}               服务器进程文件\"$proc\"不存在，可能已移除或删除了哦$RES"
    fi
fi
}

#重启服务器
function restart_srv(){
clear
echo -e "${YELLOW_COLOR}              登陆用户：$(logname)  操作时间：`date +%F\ %T`$RES" | tee -a $restart_log
if [ -e "$datadir/$proc" ]; then
  sudo chmod a+x $datadir/yshd_game
  sudo kill -2 $process_PID
  countdown
  [ $process_NUM -ne 0 ] && {
    echo -e "${GREEN_COLOR}                       服务器重启完成$RES" | tee -a $restart_log
  }
else
  echo -e "${RED_COLOR}          注意:服务器进程文件\"$proc\"不存在，可能已移除或删除了哦$RES"
fi
}

#确认升级操作
function sure_1(){
while true :
do
  read -r -p "你确定吗(Are You Sure)[y/N]: " input
  case "$input" in
   [yY][eE][sS]|[yY])
    stop_listen
    upgrade_srv
    cont_listen
    break
    ;;

   [nN][oO]|[nN])
    exit 1
    break
    ;;

   *)
    echo "invalid input..."
    ;;

  esac
done
}

#确认重启操作
function sure_2(){
while true :
do
  read -r -p "你确定吗(Are You Sure)[y/N]: " input
  case "$input" in
   [yY][eE][sS]|[yY])
    stop_listen
    restart_srv
    cont_listen
    break
    ;;

   [nN][oO]|[nN])
    exit 2
    break
    ;;

   *)
    echo "invalid input..."
    ;;

  esac
done
}

#主函数
function main(){
while :
do
trapper
clear
cat << menu
       ----------------------------------------------
      |                                              |
      |      1.  升级服务器 [Upgrade Server]         |
      |      2.  重启服务器 [Restart Server]         |
      |      3.  退出 [ByeBye]                       |
      |                                              |
       ----------------------------------------------
menu
read -p "请输入对应的序号(Please Enter The Numbers): " num
echo ""
case $num in
  1)
  sure_1
  break
  ;;

  2)
  sure_2
  break
  ;;

  3)
  clear
  exit 3
  ;;

  *)
  echo "invalid input..."
 esac
done
}

main
